module LatticeCryptoNTRUBouncy {
	requires org.bouncycastle.provider;
}